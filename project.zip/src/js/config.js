// Example configuration file for API keys
// Copy this file to src/js/config.js and replace with your own API key
export const GOOGLE_MAPS_API_KEY = 'AIzaSyDLwMRu47yXHBbfX4cimCx9BnIEtdmd0zk';


