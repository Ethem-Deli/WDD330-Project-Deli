// src/js/firebase-config.example.js
// Copy this file to src/js/firebase-config.js
// and fill in your real Firebase project credentials.
// Do NOT commit the real firebase-config.js file to GitHub.

export const firebaseConfig = {
    apiKey: "AIzaSyB92OXlJn50jta9IHuY5czC937HMgYH2xs",
    authDomain: "historytimeline-wdd330.firebaseapp.com",
    projectId: "historytimeline-wdd330",
    storageBucket: "historytimeline-wdd330.appspot.com",
    // storageBucket: "historytimeline-wdd330.firebasestorage.app",
    messagingSenderId: "539673015003",
    appId: "1:539673015003:web:2621f434393950b78312fe",
    measurementId: "G-GV6LHVLN1R"
};
